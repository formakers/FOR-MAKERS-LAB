#!/usr/bin/env python3
# ================================================================
# Dynamixel XL330 5축 로봇 다리
# 키보드 실시간 관절 선택 + 각도 조절 + 달리기 모션 제어
# ================================================================

from dynamixel_sdk import *
import time
import math
import sys
import termios
import tty
import select

# ------------------------------------------------
# U2D2 / Dynamixel 기본 통신 설정
# ------------------------------------------------
DEVICENAME = "/dev/ttyUSB0"
BAUDRATE = 1000000
PROTOCOL_VERSION = 2.0

# XL330 Control Table 주소
ADDR_OPERATING_MODE = 11
ADDR_TORQUE_ENABLE = 64
ADDR_GOAL_POSITION = 116
ADDR_PRESENT_POSITION = 132

TORQUE_ENABLE = 1
TORQUE_DISABLE = 0
POSITION_MODE = 3

# 사용할 모터 ID
DXL_IDS = [15, 11, 12, 13, 14]

# ------------------------------------------------
# 각도 <-> Tick 변환
# XL330: 0~4095 ≈ 0~360°
# ------------------------------------------------
TICKS_PER_DEG = 4096.0 / 360.0

def deg_to_tick(deg):
    return int(deg * TICKS_PER_DEG)

def tick_to_deg(tick):
    return tick / TICKS_PER_DEG

# ------------------------------------------------
# 기본 중심각
# ------------------------------------------------
DEFAULT_CENTER = [
    180.0,   # ID15
    180.0,   # ID11
    180.0,   # ID12
    180.0,   # ID13
    180.0,   # ID14
]

# ------------------------------------------------
# 기본 움직임 크기
# ------------------------------------------------
DEFAULT_AMPLITUDE = [
    25.0,    # ID15
    30.0,    # ID11
    45.0,    # ID12
    30.0,    # ID13
    20.0,    # ID14
]

# ------------------------------------------------
# 회전 방향
# 실제 기구 방향에 따라 1/-1 수정
# ------------------------------------------------
DIRECTION = [
     1,
     1,
    -1,
     1,
    -1,
]

center = DEFAULT_CENTER.copy()
amplitude = DEFAULT_AMPLITUDE.copy()

# ------------------------------------------------
# 관절별 위상차
# ------------------------------------------------
PHASE = [
    math.radians(0),
    math.radians(55),
    math.radians(110),
    math.radians(180),
    math.radians(240),
]

run_frequency = 1.2
selected_joint = 0
running = False

def get_key():
    """Enter 없이 키보드 한 글자를 즉시 읽는다."""
    readable, _, _ = select.select([sys.stdin], [], [], 0)
    if readable:
        return sys.stdin.read(1)
    return None

# ------------------------------------------------
# Dynamixel 통신 초기화
# ------------------------------------------------
portHandler = PortHandler(DEVICENAME)
packetHandler = PacketHandler(PROTOCOL_VERSION)

print()
print("====================================================")
print(" Dynamixel 5축 로봇 다리 실시간 모션 튜닝")
print("====================================================")
print()

if not portHandler.openPort():
    print("ERROR: U2D2 포트를 열 수 없습니다.")
    print("포트 확인: ls -l /dev/ttyUSB*")
    sys.exit(1)

if not portHandler.setBaudRate(BAUDRATE):
    print("ERROR: Baudrate 설정 실패")
    portHandler.closePort()
    sys.exit(1)

print("U2D2 연결 성공:", DEVICENAME)
print("BAUDRATE:", BAUDRATE)

# ------------------------------------------------
# 모터 Position Mode + Torque ON
# ------------------------------------------------
for dxl_id in DXL_IDS:

    packetHandler.write1ByteTxRx(
        portHandler, dxl_id,
        ADDR_TORQUE_ENABLE,
        TORQUE_DISABLE
    )

    packetHandler.write1ByteTxRx(
        portHandler, dxl_id,
        ADDR_OPERATING_MODE,
        POSITION_MODE
    )

    dxl_comm_result, dxl_error = packetHandler.write1ByteTxRx(
        portHandler, dxl_id,
        ADDR_TORQUE_ENABLE,
        TORQUE_ENABLE
    )

    if dxl_comm_result != COMM_SUCCESS:
        print(
            f"ID {dxl_id} 통신 오류:",
            packetHandler.getTxRxResult(dxl_comm_result)
        )

    elif dxl_error != 0:
        print(
            f"ID {dxl_id} 오류:",
            packetHandler.getRxPacketError(dxl_error)
        )

    else:
        print(f"ID {dxl_id}: Position Mode / Torque ON")

# ------------------------------------------------
# 현재 위치 읽기
# ------------------------------------------------
print()
print("현재 Dynamixel 위치")
print("----------------------------------------------------")

for dxl_id in DXL_IDS:

    present_position, result, error = packetHandler.read4ByteTxRx(
        portHandler,
        dxl_id,
        ADDR_PRESENT_POSITION
    )

    if result == COMM_SUCCESS:
        angle = tick_to_deg(present_position)
        print(
            f"ID {dxl_id:2d} : "
            f"{present_position:4d} tick "
            f"= {angle:6.1f}°"
        )

# ------------------------------------------------
# 키 설명
# ------------------------------------------------
print()
print("====================================================")
print("키보드 실시간 제어")
print("====================================================")
print("1 : ID15 선택")
print("2 : ID11 선택")
print("3 : ID12 선택")
print("4 : ID13 선택")
print("5 : ID14 선택")
print("+ : 선택 관절 Amplitude +5°")
print("- : 선택 관절 Amplitude -5°")
print("] : 선택 관절 Center +5°")
print("[ : 선택 관절 Center -5°")
print("f : 달리기 속도 증가")
print("s : 달리기 속도 감소")
print("SPACE : RUN / STOP")
print("r : RESET")
print("q : 안전 종료")
print()

old_settings = termios.tcgetattr(sys.stdin)
tty.setcbreak(sys.stdin.fileno())

start_time = time.time()
last_print = 0

try:

    while True:

        key = get_key()

        if key is not None:

            # 숫자키로 관절 선택
            if key == '1':
                selected_joint = 0
            elif key == '2':
                selected_joint = 1
            elif key == '3':
                selected_joint = 2
            elif key == '4':
                selected_joint = 3
            elif key == '5':
                selected_joint = 4

            # 선택 관절 움직임 크기 증가
            elif key == '+' or key == '=':
                amplitude[selected_joint] += 5.0
                amplitude[selected_joint] = min(
                    amplitude[selected_joint], 90.0
                )

            # 선택 관절 움직임 크기 감소
            elif key == '-' or key == '_':
                amplitude[selected_joint] -= 5.0
                amplitude[selected_joint] = max(
                    amplitude[selected_joint], 0.0
                )

            # 중심각 증가
            elif key == ']':
                center[selected_joint] += 5.0
                center[selected_joint] = min(
                    center[selected_joint], 300.0
                )

            # 중심각 감소
            elif key == '[':
                center[selected_joint] -= 5.0
                center[selected_joint] = max(
                    center[selected_joint], 60.0
                )

            # 전체 달리기 속도 증가
            elif key == 'f':
                run_frequency += 0.1
                run_frequency = min(run_frequency, 3.0)

            # 전체 달리기 속도 감소
            elif key == 's':
                run_frequency -= 0.1
                run_frequency = max(run_frequency, 0.2)

            # 실행/정지
            elif key == ' ':
                running = not running
                start_time = time.time()
                print("\n>>> RUN" if running else "\n>>> STOP")

            # 기본값 복원
            elif key == 'r':
                center = DEFAULT_CENTER.copy()
                amplitude = DEFAULT_AMPLITUDE.copy()
                run_frequency = 1.2
                print("\n>>> RESET")

            # 종료
            elif key == 'q':
                print("\n프로그램 종료")
                break

        # ------------------------------------------------
        # 달리기 궤적 생성 및 모터 전송
        # ------------------------------------------------
        if running:

            current_time = time.time()
            t = current_time - start_time

            # 2π × 주파수 × 시간
            base_phase = (
                2.0 *
                math.pi *
                run_frequency *
                t
            )

            for i, dxl_id in enumerate(DXL_IDS):

                # 관절별 위상차가 적용된 SIN 파형
                wave = math.sin(base_phase + PHASE[i])

                # 핵심 목표각 계산식
                goal_deg = (
                    center[i]
                    +
                    DIRECTION[i]
                    *
                    amplitude[i]
                    *
                    wave
                )

                # 소프트 안전 제한
                goal_deg = max(
                    20.0,
                    min(340.0, goal_deg)
                )

                # 각도 -> Tick 변환
                goal_tick = deg_to_tick(goal_deg)

                # Dynamixel Position Mode 범위 제한
                goal_tick = max(
                    0,
                    min(4095, goal_tick)
                )

                # Goal Position 전송
                packetHandler.write4ByteTxRx(
                    portHandler,
                    dxl_id,
                    ADDR_GOAL_POSITION,
                    goal_tick
                )

        # ------------------------------------------------
        # 현재 파라미터 표시
        # ------------------------------------------------
        now = time.time()

        if now - last_print > 0.4:

            last_print = now
            joint_id = DXL_IDS[selected_joint]
            state = "RUN" if running else "STOP"

            print(
                f"\r[{state}] "
                f"선택 ID={joint_id:2d} | "
                f"Amplitude={amplitude[selected_joint]:5.1f}° | "
                f"Center={center[selected_joint]:6.1f}° | "
                f"Speed={run_frequency:4.1f}Hz ",
                end="",
                flush=True
            )

        # 약 100Hz 제어
        time.sleep(0.01)

except KeyboardInterrupt:
    print("\nCtrl+C 안전 종료")

finally:

    # 터미널 입력 모드 원상 복원
    termios.tcsetattr(
        sys.stdin,
        termios.TCSADRAIN,
        old_settings
    )

    print()
    print("모든 Dynamixel Torque OFF")

    for dxl_id in DXL_IDS:
        packetHandler.write1ByteTxRx(
            portHandler,
            dxl_id,
            ADDR_TORQUE_ENABLE,
            TORQUE_DISABLE
        )

    portHandler.closePort()

    print("U2D2 Port Closed")
    print("프로그램 종료")
