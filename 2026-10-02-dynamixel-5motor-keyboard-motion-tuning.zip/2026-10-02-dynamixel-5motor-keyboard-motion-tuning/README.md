# Dynamixel 5-Motor Keyboard Motion Tuning

Dynamixel XL330 모터 5개와 U2D2, Ubuntu, Python을 이용해 만든 한쪽 로봇 다리의 **실시간 모션 튜닝 실험**입니다.

키보드로 원하는 관절을 선택한 뒤 `+ / -` 키로 움직임 크기(Amplitude)를 바로 조절할 수 있습니다.  
달리기 동작을 실행하면서 각 관절의 움직임을 눈으로 확인하고, 원하는 동작을 찾는 것이 목적입니다.

---

## 1. 시스템 개요

```text
Keyboard
   ↓
Joint Select (1~5)
   ↓
Center / Amplitude / Speed Adjustment
   ↓
Running Trajectory Generator
   ↓
Goal Angle
   ↓
Degree → Dynamixel Tick
   ↓
U2D2
   ↓
Dynamixel XL330 × 5
   ↓
One-Leg Running Motion
```

---

## 2. 사용 하드웨어

- Dynamixel XL330-M288-T × 5
- U2D2
- Ubuntu PC
- 5축 한쪽 로봇 다리 프레임
- 전원 공급 장치
- Dynamixel 케이블

### 모터 ID

```text
ID15
ID11
ID12
ID13
ID14
```

실제 관절 역할은 기구 배치에 맞게 수정하면 됩니다.

---

## 3. 사용 소프트웨어

- Ubuntu
- Python 3
- Dynamixel SDK
- Linux terminal keyboard input
- Python `math`, `time`, `termios`, `tty`, `select`

---

## 4. 키보드 조작

| 키 | 기능 |
|---|---|
| `1` | ID15 선택 |
| `2` | ID11 선택 |
| `3` | ID12 선택 |
| `4` | ID13 선택 |
| `5` | ID14 선택 |
| `+` | 선택 관절 Amplitude +5° |
| `-` | 선택 관절 Amplitude -5° |
| `]` | 선택 관절 Center +5° |
| `[` | 선택 관절 Center -5° |
| `f` | 달리기 속도 증가 |
| `s` | 달리기 속도 감소 |
| `Space` | RUN / STOP |
| `r` | 기본값으로 RESET |
| `q` | 안전 종료 |

---

## 5. 핵심 제어 원리

각 관절의 목표각은 다음 식으로 계산합니다.

```text
Goal Angle
=
Center
+
Direction × Amplitude × sin(Phase)
```

- `Center` : 관절의 기준 중심각
- `Amplitude` : 중심에서 얼마나 크게 움직일지 결정
- `Direction` : 회전 방향 (`1` 또는 `-1`)
- `Phase` : 관절별 시간차
- `Run Frequency` : 전체 동작 속도

예를 들어 Center가 180°, Amplitude가 45°이면 관절은 대략 135°~225° 범위에서 움직일 수 있습니다.

---

## 6. 이번 실험의 핵심

처음부터 완벽한 달리기 동작을 만드는 것이 아니라,

```text
기본 동작 실행
   ↓
관절 하나 선택
   ↓
각도 크기 증가 / 감소
   ↓
실제 움직임 확인
   ↓
다시 조절
   ↓
마음에 드는 모션 찾기
```

과정을 반복합니다.

이 방식은 로봇의 **Motion Tuning / Calibration** 과정의 기초입니다.

---

## 7. 실행 방법

### 7-1. 포트 확인

```bash
ls -l /dev/ttyUSB*
```

예:

```text
/dev/ttyUSB0
```

### 7-2. 파일 열기

```bash
nano ~/dynamixel_5motor_keyboard_run_detailed.py
```

### 7-3. 문법 검사

```bash
python3 -m py_compile ~/dynamixel_5motor_keyboard_run_detailed.py
```

### 7-4. 실행

```bash
python3 ~/dynamixel_5motor_keyboard_run_detailed.py
```

---

## 8. 안전 주의사항

- 처음에는 다리를 바닥에서 띄운 상태 또는 지그에 고정한 상태로 테스트합니다.
- 실제 기구의 관절 한계에 맞게 각도 범위를 줄입니다.
- Amplitude를 한 번에 크게 올리지 않습니다.
- 모터 방향이 반대라면 `DIRECTION` 값을 `1 ↔ -1`로 변경합니다.
- 비상 상황에서는 `q` 또는 `Ctrl+C`로 종료합니다.
- 종료 시 Torque OFF가 실행되도록 구성되어 있습니다.
- 빠른 동작에서는 전원 용량, 케이블, 프레임 간섭을 반드시 확인합니다.

---

## 9. 다음 개발 단계

1. 마음에 드는 모션 파라미터를 CSV로 저장
2. 키프레임 기반 달리기 모션 제작
3. 착지 → 압축 → 차기 → 회수 → 전방 스윙 단계 분리
4. IMU를 이용한 균형 보정
5. 발바닥 힘 센서를 이용한 착지 감지
6. 양쪽 다리 확장
7. ROS 2 및 Physical AI 제어와 연동

---

## 10. 프로젝트 목적

이 프로젝트의 목적은 단순히 모터를 움직이는 것이 아니라,  
**실제 로봇의 움직임을 보면서 관절별 파라미터를 실시간으로 조절하고, 자연스러운 움직임을 데이터로 만들어가는 것**입니다.
