// 단위 mm. 조립 시험용. 모터 나사 위치를 가정하지 않는 스트랩 크래들.
$fn=96;
part="assembly";
module hole(r=1.7,h=100){translate([0,0,-1])cylinder(r=r,h=h);}
module slot(len=12,d=3.4,h=20){hull(){translate([0,-len/2,0])cylinder(d=d,h=h);translate([0,len/2,0])cylinder(d=d,h=h);}}
posts=[[-52,-52],[-52,52],[52,-52],[52,52]];
module base(){
 difference(){
  translate([-80,-80,0])cube([160,160,6]);
  for(p=posts)translate([p[0],p[1],0])hole();
  for(x=[-23,23])translate([x,-12,-1])slot(24,3.4,8);
  for(x=[-72,72],y=[-72,72])translate([x,y,0])hole(2.2);
 }
}
module post(){
 difference(){cylinder(d=11,h=42);hole(1.7,45);}
}
module ring(){
 difference(){
 union(){
 linear_extrude(4)union(){
 difference(){circle(d=142);circle(d=104);}
 for(p=posts)translate(p)circle(d=13);
 }
 translate([0,0,3.85])linear_extrude(.75)union(){
 for(a=[0:359])rotate(-a)translate([-.225,53])
 square([.45,a%10==0?5:a%5==0?3.6:2.2]);
 for(a=[0:10:350])rotate(-a)translate([0,64])
 text(str(a),size=a%90==0?4:3.4,halign="center",valign="center",font="DejaVu Sans:style=Bold");
 }
 }
 for(p=posts)translate([p[0],p[1],0])hole();
 }
}
module cradle(){
 difference(){
 union(){
 translate([-28,-28,0])cube([56,56,5]);
 for(x=[-17.65,14.65])translate([x,-23.65,4.8])cube([3,47.3,10]);
 }
 // 관통 슬롯으로 스트랩 두 줄을 모터 둘레에 감는다.
 for(x=[-20,20],y=[-13,13])translate([x-1.5,y-3,-1])cube([3,6,8]);
 for(x=[-23,23])translate([x,0,-1])slot(14,3.4,8);
 }
}
module shim(){difference(){cylinder(d=11,h=1);hole(1.7,4);}}
module pointer(){
 // 기존 원판 위에 접착하는 별도 부품. 체결 구멍은 원판 실측 후 추가.
 linear_extrude(1.2)polygon([[-2,0],[2,0],[.55,15],[0,17],[-.55,15]]);
}
if(part=="base")base();
if(part=="post")post();
if(part=="ring")ring();
if(part=="cradle")cradle();
if(part=="shim")shim();
if(part=="pointer")pointer();
if(part=="assembly"){
 color("slategray")base();
 for(p=posts)translate([p[0],p[1],6])color("gray")post();
 translate([0,0,48])color("white")ring();
 translate([0,-12,6])color("orange")cradle();
 // 반투명 모터 외형은 참고용이며 출력 부품이 아님.
 %translate([-14.25,-35.25,11])cube([28.5,46.5,34]);
}
