import bpy,os,math,json,bmesh
from mathutils import Vector
out=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(out,'../upload/horn_truss_8_100mm(1).blend'))
scene=bpy.context.scene
# 기존 원판은 형상 보존, 위치만 조립 참고 위치로 이동.
rotor=bpy.data.objects.get('Horn_Truss_8_D100_T5_mm')
rotor.location.z=.048
for o in list(scene.objects):
 if o.type=='MESH' and o!=rotor:bpy.data.objects.remove(o,do_unlink=True)
def material(name,c):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(*c,1);return m
gray=material('Base',(.15,.2,.25)); ivory=material('Ring',(.82,.85,.9)); orange=material('Cradle',(.8,.3,.035)); red=material('Pointer',(.8,.02,.02))
results=[]
def load(part,loc,mat,name=None):
 bpy.ops.wm.stl_import(filepath=os.path.join(out,part+'.stl'))
 o=bpy.context.object;o.name=name or part;o.scale=(.001,)*3;o.location=loc;o.data.materials.clear();o.data.materials.append(mat)
 bpy.context.view_layer.update()
 bm=bmesh.new();bm.from_mesh(o.data)
 bad=sum(not e.is_manifold for e in bm.edges)
 results.append({'part':o.name,'non_manifold_edges':bad,'vertices':len(bm.verts),'dimensions_mm':[round(v*1000,3) for v in o.dimensions]})
 assert bad==0,(part,bad)
 bm.free();return o
sh=load('shim',(.09,0,0),gray);sh.hide_render=True;sh.hide_set(True)
load('base',(0,0,0),gray)
load('cradle',(0,-.012,.006),orange)
for x in [-.052,.052]:
 for y in [-.052,.052]:load('post',(x,y,.006),gray,'Post_%s_%s'%(x,y))
load('fixed_ring',(0,0,.048),ivory,'ring')
load('pointer',(0,.036,.054),red)
# 재료 색을 눈금 위로 칠하는 효과만 추가. STL은 단일 솔리드.
ring=bpy.data.objects.get('ring'); dark=material('Markings',(.025,.025,.03));ring.data.materials.append(dark)
for p in ring.data.polygons:
 if p.center.z>4.15:p.material_index=1
# 단순 모터 외형 참고 박스
bpy.ops.mesh.primitive_cube_add(size=1,location=(0,-.012,.028))
motor=bpy.context.object;motor.name='REFERENCE_MOTOR_ENVELOPE_NOT_PRINT';motor.dimensions=(.0285,.0465,.034);motor.data.materials.append(gray)
scene.render.engine='CYCLES';scene.cycles.samples=24
scene.render.resolution_x=1400;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
scene.view_settings.exposure=0;scene.view_settings.view_transform='AgX'
for o in scene.objects:
 if o.type=='LIGHT':o.data.energy=.7
cam=scene.camera;cam.location=(.19,-.24,.25);cam.rotation_euler=(Vector((0,0,.025))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=.25
for screen in bpy.data.screens:
 for a in screen.areas:
  if a.type=='VIEW_3D':a.spaces.active.region_3d.view_distance=.3;a.spaces.active.region_3d.view_location=(0,0,.025)
with open(os.path.join(out,'mesh_validation.json'),'w') as f:json.dump(results,f,indent=2)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(out,'XL430_fixture_assembly.blend'))
scene.render.filepath=os.path.join(out,'assembly_preview.png');bpy.ops.render.render(write_still=True)
