import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const $ = id => document.getElementById(id);
const scene = new THREE.Scene();scene.background=new THREE.Color(0x18253a);
const camera = new THREE.PerspectiveCamera(44,1,.05,100);camera.position.set(9,-12,10);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));
$('canvas').appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,0,.55);controls.enableDamping=true;
scene.add(new THREE.HemisphereLight(0xe8f5ff,0x4b5263,2.2));
for(const [pos,inten] of [[[8,-6,12],160], [[-8,5,9],85]]) { const lamp=new THREE.PointLight(0xffffff,inten,40);lamp.position.set(...pos);scene.add(lamp); }
const floor=new THREE.Mesh(new THREE.PlaneGeometry(30,30),new THREE.MeshStandardMaterial({color:0x273140,roughness:.9}));floor.rotation.x=0;floor.position.z=-.04;scene.add(floor);
const grid=new THREE.GridHelper(20,20,0x506a8a,0x35475e);grid.rotation.x=Math.PI/2;grid.position.z=-.035;scene.add(grid);
const rotating=new THREE.Group();scene.add(rotating);
const movingName = name => /rotating_steel|radial_spoke|diagonal_brace|center_steel_hub|center_bearing_cap|center_vertical_shaft|wheel_\d+_(STRAIGHT_ROLLER|hub_cap|bracket)|orientation_marker/i.test(name);
new GLTFLoader().load('./stage.glb', gltf => {
  const all=[];gltf.scene.updateMatrixWorld(true);gltf.scene.traverse(o=>{if(o.isMesh)all.push(o)});
  for(const obj of all){if(movingName(obj.name)){rotating.attach(obj)}else{scene.attach(obj)}}
  $('msg').textContent=`3D 모델 로드 완료 (${all.length}개 부품) · DRY RUN 준비`;
},undefined,e=>{ $('msg').textContent=`모델 로드 실패: ${e.message}`;});
function resize(){const w=$('canvas').clientWidth,h=$('canvas').clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h)};
window.addEventListener('resize',resize);resize();
let angle=0,speed=0,pressed=null,status={live_enabled:false,connected:false,armed:false,mode:null};let sending=false;
const dtclock=new THREE.Clock();
function draw(){requestAnimationFrame(draw);const dt=Math.min(.05,dtclock.getDelta());
  if(!status.armed){angle+=speed*45*dt;rotating.rotation.z=THREE.MathUtils.degToRad(-angle);}
  $('actual').textContent=angle.toFixed(1)+'°';controls.update();renderer.render(scene,camera);
}draw();
function message(txt){$('msg').textContent=txt}
async function api(body){const res=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await res.json();if(!res.ok)throw Error(data.error||'명령 실패');return data}
function updateStatus(d){ status=d;$('mode').textContent=d.armed?'LIVE':'DRY RUN';$('conn').textContent=d.connected?'XL330 연결됨':'미연결 / 시뮬레이션';$('opmode').textContent=d.mode??'-';$('arm').disabled=!d.connected||d.armed;$('off').disabled=!d.connected;
 if(d.armed&&d.position_deg!==null&&Number.isFinite(d.position_deg)){angle=d.position_deg;rotating.rotation.z=THREE.MathUtils.degToRad(-angle)}
 if(d.error) message('모터 정보: '+d.error);
}
async function refresh(){try{updateStatus(await (await fetch('/api/status')).json())}catch(e){message('서버 연결 오류: '+e.message)}}
setInterval(refresh,350);refresh();
function setMotion(dir){speed=dir*Number($('speed').value)/100;$('motion').textContent=dir>0?'정방향':dir<0?'역방향':'정지'}
async function sendManual(){if(!status.armed)return; if(status.mode!==1){message('현재 모터 모드는 속도 제어(1)가 아닙니다. 실제 연속 회전 불가');return}try{const d=await api({action:'command',kind:'manual',speed});updateStatus(d)}catch(e){message(e.message);setMotion(0)}}
const interval=setInterval(()=>{if(status.armed && speed!==0)sendManual()},120);
async function stop(){pressed=null;setMotion(0);if(status.armed && status.mode===1)await sendManual()}
function start(dir){if(pressed===dir)return;pressed=dir;setMotion(dir);sendManual()}
for(const [name,dir] of [['left',-1],['right',1]]){
 const btn=$(name);btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.setPointerCapture(e.pointerId);start(dir)});
 btn.addEventListener('pointerup',stop);btn.addEventListener('pointercancel',stop);
}
$('stop').onclick=stop;
$('speed').oninput=()=>{$('speedtxt').textContent=$('speed').value+'%';if(pressed!==null){setMotion(pressed);sendManual()}};
function isTyping(e){return e.target instanceof HTMLInputElement && ['number','text'].includes(e.target.type)}
window.addEventListener('keydown',e=>{if(isTyping(e)||e.ctrlKey||e.altKey||e.metaKey)return;
 if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space'].includes(e.code))e.preventDefault();
 if(e.code==='ArrowLeft')start(-1);if(e.code==='ArrowRight')start(1);
 if((e.code==='ArrowUp'||e.code==='ArrowDown')&&!e.repeat){$('speed').value=String(Math.max(5,Math.min(100,Number($('speed').value)+(e.code==='ArrowUp'?5:-5))));$('speed').dispatchEvent(new Event('input'))}
 if(e.code==='Space')stop();
});
window.addEventListener('keyup',e=>{if((e.code==='ArrowLeft'&&pressed===-1)||(e.code==='ArrowRight'&&pressed===1))stop()});
window.addEventListener('blur',stop);document.addEventListener('visibilitychange',()=>{if(document.hidden)stop()});
$('angle').oninput=()=>{$('target').value=$('angle').value};$('target').oninput=()=>{$('angle').value=$('target').value};
for(const btn of document.querySelectorAll('[data-angle]'))btn.onclick=()=>{$('target').value=$('angle').value=btn.dataset.angle};
$('go').onclick=async()=>{await stop();const degrees=Number($('target').value);
 if(!Number.isFinite(degrees)||Math.abs(degrees)>360){message('각도는 -360~360도 범위입니다');return}
 if(!status.armed){angle=degrees;message(`DRY RUN: 초기 위치 기준 ${degrees}°로 회전`);return}
 if(status.mode!==4){message('실제 목표각 이동은 확장 위치 모드(4)에서만 가능합니다. 현재 모드를 확인하세요.');return}
 try{updateStatus(await api({action:'command',kind:'angle',degrees}));message('목표각 명령 전달됨. 실제 현재 위치 피드백으로 화면 갱신 중')}catch(e){message(e.message)}
};
$('arm').onclick=async()=>{
 if(!confirm('무부하·전원·정지 장치·모터 모드를 확인했나요?\n토크 ON으로 실제 모터가 움직일 수 있습니다. 계속할까요?'))return;
 try{updateStatus(await api({action:'arm'}));message('LIVE 활성화. 모터 모드에 맞는 제어만 사용하세요.')}catch(e){message(e.message)}
};
$('off').onclick=async()=>{await stop();try{updateStatus(await api({action:'off'}));message('Torque OFF 실행')}catch(e){message(e.message)}};
