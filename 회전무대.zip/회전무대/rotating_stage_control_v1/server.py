#!/usr/bin/env python3
"""회전무대 데모 서버: 기본 SIM. LIVE는 명시적 플래그 + UI 승인 필요.
주의: 실제 전원 차단용 비상정지 회로를 대체하지 않습니다.
"""
import argparse, json, mimetypes, threading, time, os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlsplit
from pathlib import Path

BASE = Path(__file__).resolve().parent
TICKS_PER_REV = 4096

class Motor:
    def __init__(self, enabled=False, port='/dev/ttyUSB0', baud=1000000):
        self.enabled=enabled; self.port=port; self.baud=baud
        self.connected=False; self.armed=False; self.mode=None; self.origin=None
        self.last_cmd=time.monotonic(); self.active_velocity=False; self.last_error=''
        self.packet=None; self.port_handler=None; self.dxl=None
        self.lock=threading.RLock()
    def connect(self):
        with self.lock:
            if not self.enabled: return
            try:
                import dynamixel_sdk as dxl
                self.dxl=dxl; self.port_handler=dxl.PortHandler(self.port)
                self.packet=dxl.PacketHandler(2.0)
                if not self.port_handler.openPort(): raise RuntimeError(f'포트 열기 실패: {self.port}')
                if not self.port_handler.setBaudRate(self.baud): raise RuntimeError('통신속도 설정 실패')
                _, comm, err=self.packet.ping(self.port_handler,1)
                self.ok(comm,err)
                self.mode=self.read(11,1)
                self.origin=self.position()
                self.connected=True
            except Exception as e:
                self.last_error=str(e); self.connected=False
    def ok(self,comm,err):
        if comm != self.dxl.COMM_SUCCESS: raise RuntimeError(self.packet.getTxRxResult(comm))
        if err: raise RuntimeError(self.packet.getRxPacketError(err))
    def read(self,addr,n):
        method={1:self.packet.read1ByteTxRx,4:self.packet.read4ByteTxRx}[n]
        value,comm,err=method(self.port_handler,1,addr); self.ok(comm,err); return value
    def write(self,addr,n,value):
        method={1:self.packet.write1ByteTxRx,4:self.packet.write4ByteTxRx}[n]
        comm,err=method(self.port_handler,1,addr,int(value)); self.ok(comm,err)
    def position(self):
        v=self.read(132,4);return v if v<2**31 else v-2**32
    def velocity(self,value):
        # Goal Velocity: signed 32-bit 2's complement
        self.write(104,4,value & 0xffffffff)
    def torque_off(self):
        with self.lock:
            if self.connected:
                try: self.write(64,1,0)
                except Exception as e: self.last_error=str(e)
            self.armed=False; self.active_velocity=False
    def arm(self):
        with self.lock:
            if not self.enabled or not self.connected: raise RuntimeError('LIVE 연결 준비 안 됨')
            if self.read(64,1)!=0: raise RuntimeError('모터 토크가 이미 켜져 있습니다. 안전 확인 후 토크 OFF부터 하세요.')
            self.mode=self.read(11,1)
            if self.mode not in (1,4): raise RuntimeError(f'운전 모드 {self.mode}: 속도 모드(1) 또는 확장 위치 모드(4)가 필요합니다. 모드 자동 변경 금지.')
            self.origin=self.position()
            self.write(64,1,1)
            self.armed=True; self.last_cmd=time.monotonic()
    def command(self,data):
        with self.lock:
            if not self.armed or not self.connected: raise RuntimeError('LIVE 승인/모터 연결이 필요합니다')
            kind=data.get('kind')
            if kind=='manual':
                if self.mode!=1: raise RuntimeError('키보드 연속회전은 속도 제어 모드(1)가 필요합니다')
                speed=float(data.get('speed',0))
                if not -1<=speed<=1: raise ValueError('입력 범위 오류')
                # 낮은 속도로 제한: 1 unit ≈ 0.229 rpm, max 25 ≈ 5.7 rpm
                self.velocity(round(speed*25)); self.active_velocity=abs(speed)>0
            elif kind=='angle':
                if self.mode!=4: raise RuntimeError('360도 상대 위치 이동은 확장 위치 제어 모드(4)가 필요합니다')
                deg=float(data.get('degrees',0))
                if not -360<=deg<=360: raise ValueError('1회 명령은 ±360도만 허용')
                # 목표치는 시작점 기준 절대 각도; 누적 회전은 별도 설계 필요
                ticks=self.origin+round(deg*TICKS_PER_REV/360)
                self.write(116,4,ticks & 0xffffffff)
                self.active_velocity=False
            else: raise ValueError('알 수 없는 명령')
            self.last_cmd=time.monotonic()
    def state(self):
        with self.lock:
            result={'live_enabled':self.enabled,'connected':self.connected,'armed':self.armed,'mode':self.mode,'error':self.last_error,'position_deg':None}
            if self.connected:
                try: result['position_deg']=round((self.position()-self.origin)*360/TICKS_PER_REV,2)
                except Exception as e: result['error']=str(e)
            return result
    def watchdog(self):
        while True:
            time.sleep(.1)
            with self.lock:
                if self.armed and self.active_velocity and time.monotonic()-self.last_cmd>.35:
                    try: self.velocity(0)
                    except Exception as e: self.last_error=str(e);self.torque_off()
                    self.active_velocity=False

motor=None
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(BASE/'web'),**kwargs)
    def respond(self,code,data):
        payload=json.dumps(data,ensure_ascii=False).encode()
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(payload)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload)
    def do_GET(self):
        if urlsplit(self.path).path=='/api/status': return self.respond(200,motor.state())
        return super().do_GET()
    def do_POST(self):
        if urlsplit(self.path).path!='/api/action':return self.respond(404,{'error':'not found'})
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<2048: raise ValueError('invalid length')
            data=json.loads(self.rfile.read(n));action=data.get('action')
            if action=='arm': motor.arm()
            elif action=='off': motor.torque_off()
            elif action=='command': motor.command(data)
            else: raise ValueError('invalid action')
            return self.respond(200,motor.state())
        except Exception as e:return self.respond(400,{'error':str(e)})

def main():
    global motor
    p=argparse.ArgumentParser()
    p.add_argument('--live-enable',action='store_true',help='실제 모터 연결 허용 (추가 UI 승인 필요)')
    p.add_argument('--port',default='/dev/ttyUSB0');p.add_argument('--baud',type=int,default=1000000)
    p.add_argument('--host',default='127.0.0.1');p.add_argument('--http-port',type=int,default=8765)
    a=p.parse_args();motor=Motor(a.live_enable,a.port,a.baud);motor.connect()
    threading.Thread(target=motor.watchdog,daemon=True).start()
    srv=ThreadingHTTPServer((a.host,a.http_port),Handler)
    print(f'브라우저: http://{a.host}:{a.http_port}  LIVE={motor.enabled} 연결={motor.connected} (모터 ID=1)')
    try: srv.serve_forever()
    finally: motor.torque_off();srv.server_close()
if __name__=='__main__':main()
